#!/bin/bash

PIPE_DIR="/tmp/run/"
PIPE="${PIPE_DIR}cuckoo.${$}"
LOG_FILE="/home/eltex-pg1-v11/cuckoo.log"
PID=$$

get_timestamp() {
    date "+%Y-%m-%d %H:%M:%S"
}

print_log() {
    echo "$(get_timestamp) $1" >> "$LOG_FILE"
}

cleanup() {
    print_log "Shutdown!"

    if [ -p "$PIPE" ]; then
        rm -f "$PIPE"
    fi

    exit 0
}

trap cleanup SIGTERM

if [ ! -p "$PIPE" ]; then
    mkdir -p /tmp/run

    if [ $? -ne 0 ]; then
        print_log "Ошибка: не удалось создать каталог канала $PIPE_DIR"
        exit 1
    fi

    mkfifo "$PIPE"

    if [ $? -ne 0 ]; then
        print_log "Ошибка: не удалось создать именованный канал $PIPE"
        exit 1
    fi
fi

print_log "Startup!"

while true; do
    if read MESSAGE < "$PIPE"; then
        if [[ "$MESSAGE" =~ ^([a-zA-Z0-9_]+)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\?$ ]]; then
            NAME="${BASH_REMATCH[1]}"
            PID_REQ="${BASH_REMATCH[2]}"

            N=$((RANDOM % 9 + 2))

            echo "$N" > "$PIPE"

            print_log "$NAME[$PID_REQ] $N"
        fi
    fi
done