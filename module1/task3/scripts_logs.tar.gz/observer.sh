#!/bin/bash

CONFIG_FILE="/home/eltex-pg1-v11/observer.conf"
LOG_FILE="/home/eltex-pg1-v11/observer.log"

get_timestamp() {
    date "+%Y-%m-%d %H:%M:%S"
}

print_log() {
    echo "$(get_timestamp) [$$] $1" >> "$LOG_FILE"
}

check_and_run_script() {
    local script_path="$1"

    if [ ! -f "$script_path" ]; then
        print_log "Ошибка: Скрипт $script_path не найден в файловой системе"
        return 1
    fi

    if ! pgrep -f "$script_path" > /dev/null; then
        print_log "Запуск скрипта $script_path"

        nohup "$script_path" > /dev/null 2>&1 &
    fi
}

if [ ! -f "$CONFIG_FILE" ]; then
    print_log "Ошибка: Конфигурационный файл $CONFIG_FILE не найден"
    exit 1
fi

while IFS= read -r line || [ -n "$line" ]; do
    if [[ -n "$line" && ! "$line" =~ ^[[:space:]]*# ]]; then
        line=$(echo "$line" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')

        check_and_run_script "$line"
    fi

done < "$CONFIG_FILE"