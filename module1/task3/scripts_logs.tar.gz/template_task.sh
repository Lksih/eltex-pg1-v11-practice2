#!/bin/bash

SCRIPT_NAME=$(basename "$0")
LOG_FILE="/home/eltex-pg1-v11/report_${SCRIPT_NAME}.log"

get_timestamp() {
    date "+%Y-%m-%d %H:%M:%S"
}

print_log() {
    echo "$(get_timestamp) [$$] $1" >> "$LOG_FILE"
}

if [ "$SCRIPT_NAME" = "template_task.sh" ]; then
    print_log "я бригадир, сам не работаю"
    exit 1
fi

print_log "Скрипт запущен"

PIPE_NAME=$(find /tmp/run/ -type p 2>/dev/null | grep "/tmp/run/cuckoo\.[0-9]\+")

if [ ! -p "$PIPE_NAME" ]; then
    print_log "Ошибка: именованный канал $PIPE_NAME не найден"
    exit 1
fi

echo "${SCRIPT_NAME}[$$]: how much time do I have?" > "$PIPE_NAME"

WAIT_TIME=

if read WAIT_TIME < "$PIPE_NAME"; then
    if [[ "$WAIT_TIME" =~ ^[0-9]+$ ]]; then
        print_log "Получено время ожидания: $WAIT_TIME секунд"
        sleep "$WAIT_TIME"
    else
        print_log "Ошибка: получено некорректное время"
        exit 1
    fi
fi

print_log "Скрипт завершился, работал $WAIT_TIME секунд"
